package com.app.stores.order.exception;

public class StoresException extends Exception {

	private static final long serialVersionUID = 1L;

	public StoresException(String message) {
		super(message);
	}

}
